from keyboard import *
from penalty_gen import *
import matplotlib.pyplot as plt
from itertools import product


gram_data = {}

with open("data/data.txt", "r") as file:
    for l in file:
        new_data = l.strip("\n").split(", ")
        gram_data[new_data[0]] = [n for n in new_data[1:]]

pen = Penalty()


def get_avg(array):
    return sum(map(float, array)) / len(array)


ltrs = "juyhnm"
print(len(list(product(ltrs, repeat=2))))


key_combos = sum(
    [[ltrs[i] + ltrs[j] for j in range(i, len(ltrs))] for i in range(len(ltrs))], []
)

print(key_combos)

dists = [pen.get_bigram_penalties("".join(bg))[6] for bg in key_combos]
times = [
    get_avg(gram_data["".join(bg)] + gram_data["".join(reversed(bg))])
    for bg in key_combos
]

plt.scatter(dists, times)

# putting labels
plt.xlabel("Distance")
plt.ylabel("Time to type")

for i, txt in enumerate(key_combos):
    plt.annotate(txt, (dists[i], times[i]))

# function to show plot
plt.show()
